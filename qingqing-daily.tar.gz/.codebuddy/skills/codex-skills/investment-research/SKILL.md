---
name: investment-research
description: "AI Berkshire skill: 投资研究：巴菲特-芒格-段永平-李录 四大师综合分析框架. Source: skills/investment-research.md."
---

## Codex adapter note

This skill is generated from `skills/investment-research.md` so Claude Code and Codex users share one canonical workflow.

- Treat `$ARGUMENTS` as the user's request in the current Codex thread.
- When the source mentions Claude-only surfaces such as Task, Agent, WebSearch, Bash, Read, or Write, use the closest Codex capability available in this session: subagents when available, web search when needed, shell commands for local tools, and normal file edits for workspace files.
- Use shared project tools from `tools/` in this repository. Prefer running commands from the repository root with paths like `python3 tools/financial_rigor.py ...`; if the current thread starts outside the repo, locate the actual checkout path first instead of assuming a fixed home-directory path.
- Before starting research, run the `date` command to confirm today's date; treat it as the baseline for "latest" data and state the data cutoff date in the report header. Never assume the current date from training data.
- Preserve the research quality rules from `AGENTS.md`: cross-check financial data, use exact arithmetic tools for valuation/math, and clearly label uncertainty and source gaps.

# 投资研究：巴菲特-芒格-段永平-李录 四大师综合分析框架

对 $ARGUMENTS 进行系统化投资研究分析。

## 研究框架

基于巴菲特、芒格、段永平、李录四位投资大师的方法论，按以下七个模块顺序执行研究：

### 前置步骤：AI研究偏见自觉（必须执行）

在开始研究前，先评估该公司的"AI可研究性"，识别潜在的数据偏见：

**信息丰富度评级**：
| 等级 | 特征 | AI研究陷阱 | 应对策略 |
|------|------|-----------|---------|
| A级（信息充裕） | 上市多年、券商覆盖多、媒体报道密集 | 共识过强，AI输出趋同于市场定价，alpha有限 | 重点做反面检验：聪明人为什么不买？被忽略的风险是什么？ |
| B级（信息适中） | 上市1-3年、覆盖有限、部分数据需推算 | AI可能用"合理推测"填补空白，看起来完整实则虚假确定性 | 每个推算数据标注置信度，区分"有据推算"和"凭空填充" |
| C级（信息稀缺） | 刚上市/冷门股/新兴市场、几乎无覆盖 | AI会因资料不足而过度保守，误判为"看不清=不好" | 用第一性原理提问（见下方），从有限信息中提取商业本质 |

**C级公司的第一性原理研究法**：
当公开资料不足时，不要试图拼凑出"看起来完整"的报告，而是聚焦以下底层问题：
1. 客户是谁？为什么付钱？有没有替代选择？
2. 复购靠什么驱动？是习惯、锁定、还是持续创造新价值？
3. 竞争对手拿100亿能复制这门生意吗？
4. 管理层做过什么关键决策？这些决策反映了什么判断力和价值观？

**偏见自查清单**（研究全程保持警惕）：
- [ ] 我的"确定性"感受是来自生意本质，还是来自资料数量？
- [ ] 如果把这家公司的资料量减少一半，我的结论会变吗？
- [ ] AI输出的分析是否与市场共识高度雷同？如果是，我的信息优势在哪？
- [ ] 是否存在"公开资料很少但生意本质极好"的可能性被低估了？

将信息丰富度评级结果写入报告开头，并在最终结论中注明"AI研究置信度"与"实际投资确定性"的区别。

### 第一步：数据收集

> **数据源规范**：参见 `skills/financial-data.md`。所有财务数据必须来自两个独立来源，误差>1%须标记。
> - 美股：macrotrends（主）+ stockanalysis（副）
> - 港股：aastocks（主）+ macrotrends ADR（副）
> - A股：东方财富（主）+ 巨潮资讯（副）

使用 Task 工具启动后台 Agent，从网络收集以下数据：

1. 收入结构：最近财年及近4季度分部收入、增速、毛利率
2. 财务指标：近5年收入、净利润、毛利率、经营利润率、自由现金流、现金储备
3. 竞争格局：市场份额、主要竞争对手对比
4. 商业模式与护城河：核心竞争优势来源
5. 技术能力：核心技术栈、研发投入
6. 管理层：创始人/CEO履历、持股比例、关键决策记录
7. 行业前景：TAM（总可寻址市场）、增长预测
8. 风险因素：地缘政治、监管、供应链等
9. 当前估值：市值、PE、PS、PEG、EV/Revenue
10. 多空双方核心论点

#### 数据交叉验证（必须执行，使用金融严谨性工具）

数据收集完成后，**必须调用 `tools/financial_rigor.py` 对关键数据进行程序化验证**，杜绝LLM心算误差。

**必须验证的数据点**：
- 总股本（从交易所、Yahoo Finance、StockAnalysis 等至少2个源确认）
- 当前股价和市值（**手动计算 股价×总股本 并与报告市值对比，防止单位错误**）
- 最近财年收入和净利润（从公司年报+至少1个第三方源确认）
- 现金储备和净现金（现金+短期投资-总债务，注意口径差异）
- 管理层持股比例（区分经济权益和投票权，注意AB股结构）

**强制验证步骤（使用Bash调用工具）**：

Step 1 — 市值验算（精确十进制，非浮点）：
```bash
python3 tools/financial_rigor.py verify-market-cap \
  --price {股价} --shares {总股本} --reported {报告市值} --currency {币种}
```

Step 2 — 关键数据多源交叉验证：
```bash
python3 tools/financial_rigor.py cross-validate \
  --field {字段名} --values '{"来源1": 数值, "来源2": 数值}' --unit {单位}
```
对收入、净利润、现金储备分别执行。

Step 3 — 估值指标精确验算（PE/PB/ROE/FCF Yield 等）：
```bash
python3 tools/financial_rigor.py verify-valuation \
  --price {股价} --eps {EPS} --bvps {每股净资产} --fcf-per-share {每股FCF} --dividend {每股股息}
```

**验证规则**：
1. 每个关键数据点至少2个独立来源
2. 发现来源间有差异时，优先采用公司年报/交易所数据，并注明差异原因
3. **所有涉及计算的数据必须通过工具验算，禁止LLM心算**
4. 工具输出结果直接嵌入报告附录"关键数据交叉验证记录"
5. 如果工具报告 ❌ 偏差过大，必须排查原因后才能继续分析

**常见错误防范**：
- 市值单位：港币亿 vs 人民币亿 vs 美元亿，容易漏写/多写一个零
- FCF口径：不同来源对资本支出的定义可能不同（是否含租赁、收购等）
- 债务口径：是否包含经营租赁负债
- 持股比例：AB股公司的经济权益 ≠ 投票权

### 第二步：生意本质分析 — 段永平"对的生意"

分析要点：
- 用一句话定义这门生意的本质
- 收入结构拆解（图表）
- 5年盈利能力趋势（图表）
- 商业模式画布：一次性销售 vs 订阅/复购？硬件 vs 软件 vs 平台？
- 生态粘性/客户锁定强度
- 毛利率水平与同行对比，解释为什么高/低
- 经营杠杆分析
- **段永平式追问**：这门生意好在哪？如果只能用一句话描述，是什么？

### 第三步：护城河评估 — 巴菲特"经济护城河"

逐一验证五类护城河：

| 护城河类型 | 验证方法 |
|-----------|---------|
| 品牌/定价权 | 是否能在不损失销量的情况下提价？ |
| 转换成本 | 客户迁移到竞品的成本有多高？ |
| 网络效应 | 用户越多产品越好吗？ |
| 规模效应 | 规模带来的成本优势有多大？ |
| 技术/专利壁垒 | 技术领先几年？能否被复制？ |

分析护城河趋势：过去5年变宽还是变窄？未来5年预判。

**巴菲特式追问**：10年后这条护城河还在吗？什么能摧毁它？

### 第四步：逆向思考与风险清单 — 芒格"反过来想"

- 列出"这家公司可能失败的所有路径"（表格：路径/概率/影响程度）
- 历史类比：找到历史上处于相似位置的公司，结局如何？
- 跨学科分析：用网络效应理论、技术采纳曲线、竞争博弈等模型交叉验证
- 偏误自查：叙事偏差、锚定效应、幸存者偏差
- 收集空方核心论点

**芒格式追问**：我最可能在哪里犯错？聪明人为什么会不买/做空这家公司？

### 第五步：管理层评估 — 段永平"对的人" + 巴菲特"管理层诚信"

- CEO/创始人关键决策复盘（表格：时间/决策/结果/评分）
- 资本配置能力：研发回报率、并购成功率、回购时机
- 股东利益一致性：管理层持股、薪酬结构、减持记录
- 组织能力：团队稳定性、关键人才风险
- 企业文化特征

**段永平式追问**：如果CEO退休，这家公司还能保持竞争力吗？

### 第六步：行业与文明趋势 — 李录"文明演进框架"

- 判断所在行业是否处于"文明级范式转移"
- 历史技术革命类比（蒸汽机/电力/互联网/AI）
- TAM增长曲线与天花板分析
- 公司在产业价值链中的位置
- 技术路线风险
- 客户/供应商集中度分析

**李录式追问**：站在20年后回看，这家公司是"这个时代的标准石油"还是"昙花一现的3Com"？

### 第七步：估值与安全边际 — 巴菲特"内在价值" + 段永平"对的价格"

- 当前市场定价（关键估值指标表格）—— **必须通过工具验算**
- 反向DCF：当前股价隐含了什么增长预期？
- 三情景估值 —— **必须通过工具精确计算，禁止心算**：
```bash
python3 tools/financial_rigor.py three-scenario \
  --price {股价} --eps {EPS} --shares {总股本亿} \
  --growth {乐观增速} {中性增速} {悲观增速} \
  --pe {乐观PE} {中性PE} {悲观PE} --years 3 --currency {币种}
```
- 与自身历史估值对比
- 与同行估值对比

**段永平式追问**：如果股市明天关闭5年，你愿意以这个价格持有吗？

### 第八步：综合决策备忘录

汇总表格：

| 维度 | 结论 | 信心度 |
|------|------|--------|
| 生意质量（段永平） | | |
| 护城河（巴菲特） | | |
| 管理层（段永平+巴菲特） | | |
| 最大风险（芒格） | | |
| 文明趋势（李录） | | |
| 估值（巴菲特+段永平） | | |

最终决策表格：

| 策略 | 建议 |
|------|------|
| 空仓者 | |
| 持仓者 | |
| 卖出信号 | |
| 加仓信号 | |

四位大师的模拟点评（用引用格式）。

## 输出要求

1. 所有分析必须有数据支撑，附数据来源
2. 使用 Markdown 表格呈现关键数据
3. 每个模块末尾必须有对应大师的"追问"
4. 最终将完整报告写入 `~/[公司名]投资研究报告.md`
5. 结论要明确，不回避给出买入/观望/回避的建议
6. 估值部分必须给出具体的价格区间
7. **报告开头**必须包含"信息丰富度评级"（A/B/C）和"AI研究局限性声明"
8. **报告结尾**必须区分"AI分析置信度"与"投资确定性"——前者取决于资料量，后者取决于生意本质。明确告知读者：本报告的哪些结论基于充分数据，哪些基于有限信息的推理
9. 如果公司属于C级（信息稀缺），报告末尾必须列出"需要一手验证的问题清单"——建议读者通过田野调查、产品体验、供应链访谈等方式补充AI的盲区

## 数据抽检（准出流程）

报告写入文件后，**必须**执行数据抽检，通过后方可发布：

**Step 1 — 提取抽检清单（15%随机抽样）：**
```bash
python3 tools/report_audit.py extract \
  --report <报告文件路径>
```
输出 JSON 模板，每项含 `fetched_value`（待填）。

**Step 2 — 取数核验：**
对清单中每个数据点，按 `skills/financial-data.md` 规范从可靠信源取数
（美股：macrotrends+stockanalysis；港股：aastocks+macrotrends；A股：东方财富+巨潮资讯），
填入 `fetched_value` / `fetched_source` / `fetched_value2` / `fetched_source2`。

**Step 3 — 输出判决：**
```bash
python3 tools/report_audit.py verdict \
  --results '<填好的JSON>' \
  --report <报告文件名>
```

- **【准出】**：所有抽检点偏差 ≤ 1% → 报告可发布
- **【打回】**：任意点偏差 > 1% → 修正对应数据后重新抽检，直到准出
