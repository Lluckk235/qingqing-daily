---
name: portfolio-review
description: "AI Berkshire skill: 组合管理：从\"研究公司\"到\"管理组合\". Source: skills/portfolio-review.md."
---

## Codex adapter note

This skill is generated from `skills/portfolio-review.md` so Claude Code and Codex users share one canonical workflow.

- Treat `$ARGUMENTS` as the user's request in the current Codex thread.
- When the source mentions Claude-only surfaces such as Task, Agent, WebSearch, Bash, Read, or Write, use the closest Codex capability available in this session: subagents when available, web search when needed, shell commands for local tools, and normal file edits for workspace files.
- Use shared project tools from `tools/` in this repository. Prefer running commands from the repository root with paths like `python3 tools/financial_rigor.py ...`; if the current thread starts outside the repo, locate the actual checkout path first instead of assuming a fixed home-directory path.
- Before starting research, run the `date` command to confirm today's date; treat it as the baseline for "latest" data and state the data cutoff date in the report header. Never assume the current date from training data.
- Preserve the research quality rules from `AGENTS.md`: cross-check financial data, use exact arithmetic tools for valuation/math, and clearly label uncertainty and source gaps.

# 组合管理：从"研究公司"到"管理组合"

对 $ARGUMENTS 执行投资组合审视与优化。

**支持输入格式**：
- 持仓清单，例如：`腾讯30%, 美团20%, 茅台20%, 英伟达15%, 现金15%`
- 或：`腾讯 500股 @480港元, 美团 1000股 @130港元, ...`
- 或：`我的持仓`（如果已有保存的组合文件 `reports/portfolio-latest.md`）

> "分散投资是对无知的保护。如果你知道自己在做什么，分散投资就没有意义。" —— 巴菲特
>
> "我这辈子见过的真正好的投资机会，十个手指就数得完。" —— 李录

## 设计理念

研究公司只是投资的一半。另一半是**组合层面的决策**：
- 买多少？（仓位）
- 用什么钱买？（资金来源——新钱还是换仓）
- 和已有持仓是否冲突？（相关性）
- 最优组合长什么样？（机会成本）

巴菲特从不孤立地看一只股票——他总是在想"这是不是我能做的最好的事？"

## 执行流程

### 第一步：解析持仓

从输入中解析出当前持仓，标准化为以下格式：

| 标的 | 代码 | 持仓量 | 成本价 | 现价 | 市值 | 占比 | 盈亏 |
|------|------|--------|-------|------|------|------|------|

如果输入只有比例没有金额，按比例分析即可。

同时检查是否存在已有的组合文件（`reports/portfolio-latest.md`），如有则读取并更新。

### 第二步：获取最新数据

使用 Task 工具启动后台 Agent，通过 WebSearch 为每个持仓并行获取：
1. 当前股价和估值指标（PE、PB、股息率）
2. 最近一个季度的关键财务变化
3. 近期重大事件
4. 分析师一致预期（前瞻PE、目标价）

对每个持仓使用 `tools/financial_rigor.py verify-valuation` 校验估值数据。对每只持仓标注信息丰富度（A/B/C级），C级持仓的分析结论标注低置信度。

### 第三步：单仓位体检

对每个持仓进行快速健康检查：

| 标的 | 当前PE | 买入逻辑是否变化 | 论文健康度 | 仓位建议 |
|------|:------:|:--------------:|:---------:|---------|
| 腾讯 | 18x | 未变化 | 8/10 | 合理 |
| 美团 | 25x | 竞争加剧 | 6/10 | 偏高，考虑减仓 |

对每个持仓回答：
- [ ] **如果今天没有持仓，你还会在当前价格买入吗？**
- [ ] **如果明天不能交易，持有5年你舒服吗？**
- [ ] **买入论文还完整吗？**

**段永平**："如果你不想持有一只股票10年，那就一天也不要持有。"

### 第四步：组合层面分析

#### 4.1 集中度分析

| 指标 | 当前值 | 建议范围 | 判断 |
|------|-------|---------|------|
| 第一大持仓占比 | | <40% | |
| 前三大持仓占比 | | 50-80% | |
| 总持仓数量 | | 5-15只 | |
| 现金占比 | | 10-30%（视市场环境） | |

**李录的标准**：3-5只核心持仓，前3占80%+。**但这要求每一只都研究透彻。**

**巴菲特的标准**：核心持仓不超过10只，但允许更多卫星仓位。

#### 4.2 相关性检查

识别持仓之间的隐性关联：

| 持仓A | 持仓B | 相关类型 | 风险 |
|-------|-------|---------|------|
| 腾讯 | 快手 | 同属中国互联网 | 监管风险共振 |
| 英伟达 | 台积电 | AI供应链上下游 | AI Capex同向波动 |
| 美团 | 拼多多 | 同属中国消费 | 宏观消费同向波动 |

**检查清单**：
- [ ] 是否有超过50%的仓位暴露在同一个主题/行业？
- [ ] 是否有超过50%的仓位暴露在同一个国家/货币？
- [ ] 如果中美关系恶化，组合会亏多少？
- [ ] 如果全球经济衰退，组合会亏多少？

#### 4.3 机会成本分析

这是巴菲特最核心的思维方式——**每一块钱都应该放在回报最高的地方**。

将所有持仓按"预期年化回报"排序：

| 排名 | 标的 | 当前占比 | 预期年化回报 | 确定性 | 预期回报×确定性 |
|:----:|------|:-------:|:----------:|:------:|:--------------:|
| 1 | | | | | |
| 2 | | | | | |
| ... | | | | | |

预期回报估算方法（使用 `tools/financial_rigor.py three-scenario` 计算）：
- **简化公式**：预期年化 ≈ FCF Yield + 预期增速（主要方法）
- **价值型验证**：安全边际回归 + 利润增速 + 股息率
- **成长型验证**：利润增速 × 合理PE的变化

**关键问题**：排名最后的持仓，预期回报是否高于现金（无风险利率~4%）？如果不是，应该卖出换成现金。

#### 4.4 压力测试

| 情景 | 假设 | 组合预计影响 | 最大回撤 |
|------|------|-----------|---------|
| 全球衰退 | 企业盈利下降20-30% | | |
| 中美冲突升级 | 中概股折价50% | | |
| 利率飙升 | 10年期国债→6% | | |
| 科技泡沫破裂 | 科技股PE压缩40% | | |

对每个情景做定性+粗估评估（基于各持仓的行业属性和历史估值波动范围）：
- 哪些持仓受冲击最大？大致影响方向和量级范围
- 组合整体是否能承受？
- 是否需要对冲？

### 第五步：优化建议

#### 5.1 调仓建议

基于以上分析，给出具体的调仓建议：

| 动作 | 标的 | 当前占比 | 建议占比 | 理由 |
|------|------|:-------:|:-------:|------|
| 加仓 | | | | |
| 减仓 | | | | |
| 清仓 | | | | |
| 新建仓 | | | | |
| 不动 | | | | |

#### 5.2 寻找替代标的

如果组合中有"不如现金"的仓位，或者现金占比过高，建议使用 `/industry-research` 或 `/investment-checklist` 对感兴趣的行业/公司进行系统筛选，而非在本Skill内直接推荐个股。

#### 5.3 现金管理

| 当前现金占比 | 建议现金占比 | 理由 |
|:----------:|:----------:|------|

**巴菲特**：目前持有$3,820亿现金，占比超过总资产的25%——当找不到好机会时，现金是最好的仓位。

### 第六步：输出组合报告

#### 报告结构

```
一、组合概览（持仓表格+饼图描述）
二、单仓位体检（每个持仓的健康状态）
三、组合分析
   - 集中度：是否过度分散/集中？
   - 相关性：隐性关联和风险共振
   - 机会成本：排名最低的仓位是否值得持有？
   - 压力测试：极端情景下的回撤预估
四、调仓建议（具体操作+理由）
五、下次审视时间和关注重点
```

#### 结论必须明确回答

1. **组合整体健康度**：优秀 / 良好 / 需要调整 / 问题严重
2. **最应该做的一件事是什么？**（加仓X / 减仓Y / 不动）
3. **当前最大风险是什么？**

### 第七步：保存组合文件

将组合信息写入 `reports/portfolio-latest.md`，包含：
- 最新持仓表
- 本次审视日期和结论
- 调仓记录（追加）
- 下次审视提醒

---

## 关键原则

- **每一块钱都有机会成本** — 持有一只平庸的股票，成本是错过了一只优秀的
- **集中不是风险，无知才是** — 持有3只你深度理解的股票，比持有30只你一知半解的安全
- **现金是一种仓位** — 找不到好机会时，持有现金不丢人
- **组合层面 > 个股层面** — 一只好股票在错误的仓位上也会拖累你
- **定期审视，但不要过度交易** — 每季度审视一次足够，不要每天盯盘调仓
